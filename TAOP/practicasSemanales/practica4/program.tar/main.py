import sys

casos = sys.stdin.read()
casos = casos.split("\n\n")
for caso in casos:
    if caso == "0 0\n":
        print("\n\n")
        exit()

    A, B = int(caso[0]), int(caso[2])
    linea = caso.split("\n")[1:A+1]#cogemos de la primera a la última fila
    obs = {}
    for i in range(A):
        obs[i] = linea[i].split(" ")

    j, path, indexpath = 0, [], []
    while j < B:
        i, col = 0, []
        while i < A :
            col.append(int(obs[i][j]))
            i += 1
        smallest = min(col)
        indexpath.append(col.index(smallest))
        path.append(smallest)
        j += 1

    speed = {}
    time = 0
    while len(speed) != len(path):
        big = path.index(max(path))
        if big not in speed:
            speed[big] = "F"
            time += path[big]
            path[big] = 0
            if big+1 != len(path) and big+1 not in speed:
                speed[big + 1] = "H"
                time += path[big + 1] * 2
                path[big + 1] = 0
            if big-1 != -1 and big-1 not in speed:
                time += path[big - 1] * 2
                speed[big - 1] = "H"
                path[big - 1] = 0

    print(time)
    indexstr: str = ""
    for elem in indexpath: indexstr += f"\t{elem}"
    speedstr = ""
    for i in range(len(speed)): speedstr += f"\t{speed[i]}"
    print(indexstr,"\n",speedstr, "\n")
